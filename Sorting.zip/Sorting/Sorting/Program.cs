﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sorting
{
    class Program
    {
        public static void PrintIntegerArray(int[] array)
        {
            foreach (int i in array)
            {
                Console.Write(i.ToString() + "  ");
            }
        }
        public static int[] InsertionSortByShift(int[] inputArray)
        {
            for (int i = 0; i < inputArray.Length - 1; i++)
            {
                int j;
                var insertionValue = inputArray[i];
                for (j = i; j > 0; j--)
                {
                    if (inputArray[j - 1] > insertionValue)
                    {
                        inputArray[j] = inputArray[j - 1];
                    }
                }
                inputArray[j] = insertionValue;
            }
            return inputArray;
        }
        public class example
        {
            static void heapSort(int[] arr, int n)
            {
                for (int i = n / 2 - 1; i >= 0; i--)
                    heapify(arr, n, i);
                for (int i = n - 1; i >= 0; i--)
                {
                    int temp = arr[0];
                    arr[0] = arr[i];
                    arr[i] = temp;
                    heapify(arr, i, 0);
                }
            }
            static void heapify(int[] arr, int n, int i)
            {
                int largest = i;
                int left = 2 * i + 1;
                int right = 2 * i + 2;
                if (left < n && arr[left] > arr[largest])
                    largest = left;
                if (right < n && arr[right] > arr[largest])
                    largest = right;
                if (largest != i)
                {
                    int swap = arr[i];
                    arr[i] = arr[largest];
                    arr[largest] = swap;
                    heapify(arr, n, largest);
                }
            }
            private static void Quick_Sort(int[] arr, int left, int right)
            {
                if (left < right)
                {
                    int pivot = Partition(arr, left, right);

                    if (pivot > 1)
                    {
                        Quick_Sort(arr, left, pivot - 1);
                    }
                    if (pivot + 1 < right)
                    {
                        Quick_Sort(arr, pivot + 1, right);
                    }
                }

            }

           private static int Partition(int[] arr, int left, int right)
            {
                int pivot = arr[left];
                while (true)
                {
                    while (arr[left] < pivot)
                    {
                        left++;
                    }
                    while (arr[right] > pivot)
                    {
                        right--;
                    }
                    if (left < right)
                    {
                        if (arr[left] == arr[right]) return right;

                        int temp = arr[left];
                        arr[left] = arr[right];
                        arr[right] = temp;
                    }
                    else
                    {
                        return right;
                    }
                }
            }
            private static void Merge(int[] input, int left, int middle, int right)
            {
                int[] leftArray = new int[middle - left + 1];
                int[] rightArray = new int[right - middle];

                Array.Copy(input, left, leftArray, 0, middle - left + 1);
                Array.Copy(input, middle + 1, rightArray, 0, right - middle);

                int i = 0;
                int j = 0;
                for (int k = left; k < right + 1; k++)
                {
                    if (i == leftArray.Length)
                    {
                        input[k] = rightArray[j];
                        j++;
                    }
                    else if (j == rightArray.Length)
                    {
                        input[k] = leftArray[i];
                        i++;
                    }
                    else if (leftArray[i] <= rightArray[j])
                    {
                        input[k] = leftArray[i];
                        i++;
                    }
                    else
                    {
                        input[k] = rightArray[j];
                        j++;
                    }
                }
            }

            private static void MergeSort(int[] input, int left, int right)
            {
                if (left < right)
                {
                    int middle = (left + right) / 2;

                    MergeSort(input, left, middle);
                    MergeSort(input, middle + 1, right);

                    Merge(input, left, middle, right);
                }
            }
                static void Main(string[] args)
            {



                Console.WriteLine("Welcome to Sorting.");
                Console.WriteLine("What type of sort would you like to use?");
                Console.WriteLine(" ");
                Console.WriteLine("1. Bubble");
                Console.WriteLine("2. Insertion");
                Console.WriteLine("3. Selection");
                Console.WriteLine("4. Heap");
                Console.WriteLine("5. Quick");
                Console.WriteLine("6. Merge");
                int userResponse = Convert.ToInt32(Console.ReadLine());


                if (userResponse == 1)
                {
                    //Bubble Sort --> repeatedly swapping the adjacent elements if they are in wrong order.
                    int[] array1 = { 3, 0, 2, 5, -1, 4, 1 };
                    int t;
                    Console.WriteLine("Original array :");
                    foreach (int aa in array1)
                        Console.Write(aa + " ");
                    for (int p = 0; p <= array1.Length - 2; p++)
                    {
                        for (int i = 0; i <= array1.Length - 2; i++)
                        {
                            if (array1[i] > array1[i + 1])
                            {
                                t = array1[i + 1];
                                array1[i + 1] = array1[i];
                                array1[i] = t;
                            }
                        }
                    }
                    Console.WriteLine("\n" + "Sorted array :");
                    foreach (int aa in array1)
                        Console.Write(aa + " ");
                    Console.Write("\n");
                }
                else if (userResponse == 2)
                {
                    //Insertion Sort --> algorithm that builds the final sorted array (or list) one item at a time.
                    int[] numbers = new int[10] { 2, 5, -4, 11, 0, 18, 22, 67, 51, 6 };
                    Console.WriteLine("\nOriginal Array Elements :");
                    PrintIntegerArray(numbers);
                    Console.WriteLine("\nSorted Array Elements :");
                    PrintIntegerArray(InsertionSort(numbers));
                    Console.WriteLine("\n");

                    static int[] InsertionSort(int[] inputArray)
                    {
                        for (int i = 0; i < inputArray.Length - 1; i++)
                        {
                            for (int j = i + 1; j > 0; j--)
                            {
                                if (inputArray[j - 1] > inputArray[j])
                                {
                                    int temp = inputArray[j - 1];
                                    inputArray[j - 1] = inputArray[j];
                                    inputArray[j] = temp;
                                }
                            }
                        }
                        return inputArray;
                    }
                }
                else if (userResponse == 3)
                {
                    //Selection Sort --> algorithm that finds the minimum value in the array for each iteration of the loop.
                    int[] arr = new int[10] { 56, 1, 99, 67, 89, 23, 44, 12, 78, 34 };
                    int n = 10;
                    Console.WriteLine("Selection sort");
                    Console.Write("Initial array is: ");
                    for (int i = 0; i < n; i++)
                    {
                        Console.Write(arr[i] + " ");
                    }
                    int temp, smallest;
                    for (int i = 0; i < n - 1; i++)
                    {
                        smallest = i;
                        for (int j = i + 1; j < n; j++)
                        {
                            if (arr[j] < arr[smallest])
                            {
                                smallest = j;
                            }
                        }
                        temp = arr[smallest];
                        arr[smallest] = arr[i];
                        arr[i] = temp;
                    }
                    Console.WriteLine();
                    Console.Write("Sorted array is: ");
                    for (int i = 0; i < n; i++)
                    {
                        Console.Write(arr[i] + " ");
                    }
                }
                else if (userResponse == 4)
                {
                    // Heap sort --> algorithm that makes use of the heap data structure.
                    int[] arr = { 55, 25, 89, 34, 12, 19, 78, 95, 1, 100 };
                    int n = 10, i;
                    Console.WriteLine("Heap Sort");
                    Console.Write("Initial array is: ");
                    for (i = 0; i < n; i++)
                    {
                        Console.Write(arr[i] + " ");
                    }
                    heapSort(arr, 10);
                    Console.Write("\nSorted Array is: ");
                    for (i = 0; i < n; i++)
                    {
                        Console.Write(arr[i] + " ");
                    }
                }
                else if (userResponse == 5)
                {
                    // Quick Sort -> a comparison sort.
                    int[] arr = new int[] { 2, 5, -4, 11, 0, 18, 22, 67, 51, 6 };

                    Console.WriteLine("Original array : ");
                    foreach (var item in arr)
                    {
                        Console.Write(" " + item);
                    }
                    Console.WriteLine();

                    Quick_Sort(arr, 0, arr.Length - 1);

                    Console.WriteLine();
                    Console.WriteLine("Sorted array : ");

                    foreach (var item in arr)
                    {
                        Console.Write(" " + item);
                    }
                    Console.WriteLine();
                }
                else if (userResponse == 6)
                {
                    //Merge Sort --> divide and conquer sort.

                    int[] arr = new int[] { 1, 5, 4, 11, 20, 8, 2, 98, 90, 16 };
                    MergeSort(arr, 0, arr.Length - 1);
                    Console.WriteLine("Sorted Values:");
                    for (int i = 0; i < arr.Length; i++)
                        Console.WriteLine(arr[i]);
                }
            }
        }
    }
}
